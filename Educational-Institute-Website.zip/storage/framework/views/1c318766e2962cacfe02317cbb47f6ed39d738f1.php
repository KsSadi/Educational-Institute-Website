<?php $__env->startSection('page-title'); ?>
    Edit Admin
<?php $__env->stopSection(); ?>




<?php $__env->startSection('admin-section'); ?>
<?php echo $__env->make('backend.layouts.partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card">
    <div class="card-header">
        <h4 class="card-title">Edit User </h4>

    </div>
    <p><hr/></p>

    <div class="card-body">
        <form action="<?php echo e(route('dashboard.admins.update', $admin->id)); ?>" method="POST">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="mb-1 row">
                    <label class="col-sm-2 col-form-label" style="font-size: medium">Name</label>
                    <div class="col-sm-10">
                    <input type="text" class="form-control" placeholder="Niamul Hasan" name="name" value=" <?php echo e($admin->name); ?>">
                </div>
                </div>

                <div class="mb-1 row">
                    <label class="col-sm-2 col-form-label" style="font-size: medium">Username</label>
                    <div class="col-sm-10">
                    <input type="text" class="form-control" placeholder="niamul_hasan" name="username" value="<?php echo e($admin->username); ?>" required>
                </div>
                </div>

                <div class="mb-1 row">
                    <label class="col-sm-2 col-form-label" style="font-size: medium">Email</label>
                    <div class="col-sm-10">
                    <input type="email" class="form-control" placeholder="username@gmail.com" name="email" value="<?php echo e($admin->email); ?>">
                </div>
                </div>
                <div class="mb-1 row">
                    <label class="col-sm-2 col-form-label" style="font-size: medium">Phone</label>
                    <div class="col-sm-10">
                        <input type="number" class="form-control"name="phone" value="<?php echo e($admin->phone); ?>" >
                    </div>
                </div>

                <div class="mb-1 row">
                    <label class="col-sm-2 col-form-label" style="font-size: medium">Password</label>
                    <div class="col-sm-10">
                    <input type="password" class="form-control" placeholder="Enter Password" name="password">
                </div>
                </div>

                <div class="mb-1 row">
                    <label class="col-sm-2 col-form-label" style="font-size: medium">Confirm Password</label>
                    <div class="col-sm-10">
                    <input type="password" class="form-control" placeholder="Confirm Password" name="password_confirmation">
                </div>
                </div>

                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($role->guard_name == 'admin'): ?>
                        <div class="col-sm-2">
                        </div>
                        <div class="col-sm-10">
                        <div class="form-check form-check-success">
                            <input type="checkbox" class="form-check-input" value="<?php echo e($role->name); ?>" name="roles[]" id="permission-<?php echo e($loop->index); ?>" <?php echo e($admin->hasRole($role) ? 'checked' : ''); ?>>
                            <label class="form-check-label" style="padding: 3px;" for="permission-<?php echo e($loop->index); ?>"><span class="badge badge bg-info"><?php echo e($role->name); ?></span></label>
                        </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="sm:ml-20 sm:pl-5 mt-5">
                    <input type="submit" class="btn btn-gradient-primary" value="Update" />
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Educational-Institute-Website\resources\views/backend/pages/admins/edit.blade.php ENDPATH**/ ?>