<!DOCTYPE html>

<html lang="en">
<!-- BEGIN: Head -->
<head>
    <meta charset="utf-8">
    <link href="dist/images/logo.svg" rel="shortcut icon">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Canteen Automation System">
    <meta name="keywords" content="Canteen Automation System">
    <meta name="author" content="CAS">
    <title><?php echo $__env->yieldContent('auth-title', 'Authentication'); ?> - Panel</title>
    <?php echo $__env->make('backend.layouts.partials.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<!-- END: Head -->
<body class="vertical-layout vertical-menu-modern blank-page navbar-floating footer-static  " data-open="click" data-menu="vertical-menu-modern" data-col="blank-page">
<div class="app-content content ">
    <div class="content-overlay"></div>
    <div class="header-navbar-shadow"></div>
    <div class="content-wrapper">
        <div class="content-header row">
        </div>

        <div class="content-body">

            <div class="auth-wrapper auth-basic px-2">
                <div class="auth-inner my-2">


                    <!-- END: Login Info -->
                    <!-- BEGIN: Login Form -->
                <?php echo $__env->yieldContent('auth-content'); ?>
                <!-- END: Login Form -->


                </div>
            </div>
        </div>
    </div>
</div>
<!-- END: Content-->
<?php echo $__env->make('backend.layouts.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH D:\Educational-Institute-Website\resources\views/backend/auth/main.blade.php ENDPATH**/ ?>