<?php $__env->startSection('page-title'); ?>
    Translates
<?php $__env->stopSection(); ?>




<?php $__env->startSection('admin-section'); ?>
    <?php echo $__env->make('backend.layouts.partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Translates</h4>

        </div>
        <p><hr/></p>

        <div class="card-body">
            <form action="<?php echo e(route('dashboard.translates.update', $translate->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="row">
                    
                    <div class="divider divider-info divider-start">
                        <div class="divider-text"> Head Teacher Speech</div>
                    </div>
                <div class="col-md-12">

                    <div class="mb-1 row">
                        <label class="col-sm-2 col-form-label" style="font-size: medium">About Us</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="about_us" value="<?php echo e($translate->about_us); ?>">
                        </div>
                    </div>

                    <div class="mb-1 row">
                        <label class="col-sm-2 col-form-label" style="font-size: medium">Designation</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="head_teacher_designation" value="<?php echo e($translate->key); ?>" >
                        </div>
                    </div>
                </div>

                    <div class="sm:ml-20 sm:pl-5 mt-5">
                        <input type="submit" class="btn btn-gradient-primary" value="Update" />
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Educational-Institute-Website\resources\views/backend/pages/translates/index.blade.php ENDPATH**/ ?>