<?php $__env->startSection('page-title'); ?>
   Notice - <?php echo e($notice->title); ?>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('admin-section'); ?>

    <?php echo $__env->make('backend.layouts.partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Notice Details </h4>

        </div>
        <p><hr/></p>

        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">

                    <tbody>

                    <tr>
                        <td>Notice Title</td>

                        <th><?php echo e($notice->title); ?></th>
                    </tr>
                    <tr>
                        <td> Description</td>

                        <td><?php echo e($notice->description); ?></td>
                    </tr>
                    <tr>
                        <td> File</td>

                        <td><a href="/storage/<?php echo e($notice->notice_file); ?>">Download</a> </td>
                    </tr>

                    <tr>
                        <td> Date </td>

                        <th><?php echo e($notice->date); ?></th>
                    </tr>

                    </tbody>
                </table>
            </div>


    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Educational-Institute-Website\resources\views/backend/pages/notices/show.blade.php ENDPATH**/ ?>