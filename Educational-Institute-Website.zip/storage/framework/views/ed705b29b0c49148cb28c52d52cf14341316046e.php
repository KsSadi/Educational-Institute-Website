<?php $__env->startSection('page-title'); ?>
    Edit Role
<?php $__env->stopSection(); ?>




<?php $__env->startSection('admin-section'); ?>
    <?php echo $__env->make('backend.layouts.partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">Edit Role </h4>

        </div>
<p><hr/></p>

        <div class="card-body">

            <form action="<?php echo e(route('dashboard.roles.update', $role->id)); ?>" method="POST">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>


                <div class="mb-1 row">
                    <label for="colFormLabel" class="col-sm-1 col-form-label" style="font-size: medium">Role Name</label>
                    <div class="col-sm-11">
                        <input type="text" class="form-control" placeholder="Admin" name="name" value="<?php echo e($role->name); ?>"/>
                    </div>
                </div>



                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-sm-2">
                    </div>
                    <div class="col-sm-10" style="margin-left: 50px">
                    <div class="form-check form-check-success">
                        <input type="checkbox" <?php echo e($role->hasPermissionTo($item->name) ? 'checked' : ''); ?> class="form-check-input" style="padding: 5px;" value="<?php echo e($item->name); ?>" name="permissions[]" id="permission-<?php echo e($loop->index); ?>">

                        <label class="form-check-label" style="padding: 3px;" for="permission-<?php echo e($loop->index); ?>"><span class="rounded-pill badge badge-light-primary"><?php echo e($item->name); ?></span></label>
                    </div>
                    </div>



                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="sm:ml-20 sm:pl-5 mt-5">
                    <input type="submit" class="btn btn-gradient-primary" value="Update" />
                </div>
        </form>

        </form>
    </div>





    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Educational-Institute-Website\resources\views/backend/pages/roles/edit.blade.php ENDPATH**/ ?>