<?php $__env->startSection('page-title'); ?>
    Edit Notice
<?php $__env->stopSection(); ?>




<?php $__env->startSection('admin-section'); ?>
<?php echo $__env->make('backend.layouts.partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card">
    <div class="card-header">
        <h4 class="card-title">Edit Notice </h4>

    </div>
    <p><hr/></p>

    <div class="card-body">
        <form action="<?php echo e(route('dashboard.notices.update', $notice->id)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="mb-1 row">
                    <label class="col-sm-2 col-form-label" style="font-size: medium">Title</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" placeholder="" name="name" value=" <?php echo e($notice->title); ?>">
                    </div>
                </div>
                <div class="mb-1 row">
                    <label class="col-sm-2 col-form-label" style="font-size: medium">Description</label>
                    <div class="col-sm-10">

                                    <textarea
                                        class="form-control"
                                        placeholder="President Speech"
                                        id="floatingTextarea2"
                                        name="description"
                                        style="height: 100px"
                                    ><?php echo e($notice->description); ?></textarea>
                    </div>
                </div>

                 <div class="mb-1 row">
                    <label class="col-sm-2 col-form-label" style="font-size: medium">Document File</label>
                    <div class="col-sm-10">
                        <input type="file" class="form-control" placeholder="" name="notice_file" value="<?php echo e($notice->notice_file); ?>">
                    </div>
                </div>


                <div class="sm:ml-20 sm:pl-5 mt-5">
                    <input type="submit" class="btn btn-gradient-primary" value="Update" />
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Educational-Institute-Website\resources\views/backend/pages/notices/edit.blade.php ENDPATH**/ ?>