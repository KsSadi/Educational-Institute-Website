<?php $__env->startSection('page-title'); ?>
    Change Password
<?php $__env->stopSection(); ?>




<?php $__env->startSection('admin-section'); ?>
<?php echo $__env->make('backend.layouts.partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card">
    <div class="card-header">
        <h4 class="card-title">Change Password </h4>

    </div>
    <p><hr/></p>

    <div class="card-body">
        <form action="<?php echo e(route('user.update-password')); ?>" method="POST" autocomplete="off">

            <?php echo csrf_field(); ?>





            <input type="hidden" name="user_id" value="<?php echo e($user->id); ?>">
            <div class="mb-1 row">
                <label class="col-sm-2 col-form-label" style="font-size: medium">Email</label>
                <div class="col-sm-10">
                    <input type="email" class="form-control"  name="email" value="<?php echo e($user->email); ?>" readonly autofocus>
                </div>
            </div>

            <div class="mb-1 row">
                <label class="col-sm-2 col-form-label" style="font-size: medium">Current Password</label>
                <div class="col-sm-10">
                    <input type="password" class="form-control" placeholder="Current Password" name="current_password" required >
                </div>
            </div>
            <div class="mb-1 row">
                <label class="col-sm-2 col-form-label" style="font-size: medium">New Password</label>
                <div class="col-sm-10">
                    <input type="password" class="form-control" placeholder="New Password" name="password" required>
                </div>
            </div>
            <div class="mb-1 row">
                <label class="col-sm-2 col-form-label" style="font-size: medium">Confirm Password</label>
                <div class="col-sm-10">
                    <input type="password" class="form-control" placeholder="Confirm Password" name="password_confirmation" required>
                </div>
            </div>
            <div class="mb-1 row">
                <div class="col-sm-10">
                    <button type="submit" class="btn btn-primary">Change Password</button>
                </div>
            </div>
        </form>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Educational-Institute-Website\resources\views/backend/pages/admins/setting.blade.php ENDPATH**/ ?>