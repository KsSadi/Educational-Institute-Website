<div class="sidenav-overlay"></div>
<div class="drag-target"></div>

<!-- BEGIN: Footer-->
<footer class="footer footer-static footer-light">
    <p class="clearfix mb-0"><span class="float-md-start d-block d-md-inline-block mt-25">&copy; Copyright <script type="text/javascript">
                var d=new Date();
                document.write(d.getFullYear());
            </script> <?php echo e($global->full_name); ?> | All Rights Reserved. </span><span class="float-md-end d-none d-md-block">Developed By <a href="https://facebook.com/mdsadi100">Sadi</a> <i data-feather="heart"></i></span></p>
</footer>
<!-- Copy Rights Start -->


<button class="btn btn-primary btn-icon scroll-top" type="button"><i data-feather="arrow-up"></i></button>
<!-- END: Footer-->


<?php /**PATH D:\Educational-Institute-Website\resources\views/backend/layouts/partials/footer.blade.php ENDPATH**/ ?>