<?php $__env->startSection('page-title'); ?>
   My Profile
<?php $__env->stopSection(); ?>




<?php $__env->startSection('admin-section'); ?>

    <?php echo $__env->make('backend.layouts.partials.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div style="padding-bottom: 15px;"></div>
    <div class="card" style="padding-top: 10px;">


        <div class="card">
            <!-- Product Details starts -->
            <div class="card-body">
                <div class="row my-2">
                    <div class="col-12 col-md-5 d-flex align-items-center justify-content-center mb-2 mb-md-0">
                        <div class="d-flex align-items-center justify-content-center">
                            <img
                                src="../../../app-assets/images/elements/profile.png"
                                class="img-fluid product-img"
                                alt="product image"
                            />
                        </div>
                    </div>
                    <div class="col-12 col-md-7">


                        <div class="ecommerce-details-price d-flex flex-wrap mt-1">
                            <h4 class="item-price me-1 primary"><b><span class="badge bg-primary"><?php echo e(Auth::guard('admin')->user()->name); ?></span> </b></h4>

                        </div>
                        <p class="card-text"> <span class="text-success">User Name</span></p>
                        <p class="card-text">
                            <?php echo e(Auth::guard('admin')->user()->username); ?>

                        </p>
                        <p class="card-text"> <span class="text-success">Email</span></p>
                        <p class="card-text">
                            <?php echo e(Auth::guard('admin')->user()->email); ?>

                        </p>
                        <p class="card-text"> <span class="text-success">Phone</span></p>
                        <p class="card-text">
                            <?php echo e(Auth::guard('admin')->user()->phone); ?>

                        </p>

                        <p class="card-text">

                        </p>
                        <hr />


                        <span class="text-success">Created at - <?php echo e(date('d-M-Y',strtotime(Auth::guard('admin')->user()->created_at))); ?></span>

                        <hr />

                </div>
            </div>
            <!-- Product Details ends -->




        </div>

        <!-- app e-commerce details end -->


    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Educational-Institute-Website\resources\views/backend/pages/admins/profile.blade.php ENDPATH**/ ?>