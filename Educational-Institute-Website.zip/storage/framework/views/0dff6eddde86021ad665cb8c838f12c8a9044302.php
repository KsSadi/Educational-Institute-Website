<!DOCTYPE html>
<html class="loading" lang="en">
<!-- BEGIN: Head -->

<head>
    <?php echo $__env->make('frontend.theme1.layouts.partials.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<!-- END: Head -->
<body>
    <!-- BEGIN: Top Bar -->
         <?php echo $__env->make('frontend.theme1.layouts.partials.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END: Top Bar -->
    <!-- BEGIN: Side Menu -->
    <!-- END: Side Menu -->
<!-- BEGIN: Content-->

                <?php echo $__env->yieldContent('frontend-section'); ?>



        <!-- END: Content -->

    <?php echo $__env->make('frontend.theme1.layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- BEGIN: JS Assets-->
    <?php echo $__env->make('frontend.theme1.layouts.partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END: JS Assets-->

    </body>
</html>
<?php /**PATH D:\Educational-Institute-Website\resources\views/frontend/theme1/layouts/main.blade.php ENDPATH**/ ?>